import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointmentMap = new HashMap<>();

    // Awesome method to create appointment
    public void addAppointment(Appointment appointment) {
        if (appointment == null || appointmentMap.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Invalid appointment or duplicate appointment ID");
        }
        appointmentMap.put(appointment.getAppointmentId(), appointment);
    }

    //  Very cool method to delete an appointment by ID
    public void deleteAppointment(String appointmentId) {
        if (!appointmentMap.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        appointmentMap.remove(appointmentId);
    }

    //  Meh method to retrieve an appointment by ID (for testing purposes)
    public Appointment getAppointment(String appointmentId) {
        return appointmentMap.get(appointmentId);
    }
}
