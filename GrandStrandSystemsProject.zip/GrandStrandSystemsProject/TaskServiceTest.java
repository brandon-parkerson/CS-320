import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("12345", "Task", "Description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("12345"));
    }

    @Test
    public void testAddDuplicateTask() {
        Task task = new Task("12345", "Task", "Description");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(new Task("12345", "Another Task", "Another Description")));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("12345", "Task", "Description");
        taskService.addTask(task);
        taskService.deleteTask("12345");
        assertNull(taskService.getTask("12345"));
    }

    @Test
    public void testDeleteNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("99999"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("12345", "Task", "Description");
        taskService.addTask(task);
        taskService.updateTaskName("12345", "New Task Name");
        assertEquals("New Task Name", taskService.getTask("12345").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("12345", "Task", "Description");
        taskService.addTask(task);
        taskService.updateTaskDescription("12345", "New Task Description");
        assertEquals("New Task Description", taskService.getTask("12345").getDescription());
    }
}
